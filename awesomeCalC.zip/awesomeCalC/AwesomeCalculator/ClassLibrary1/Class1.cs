﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using AwesomeCalculator;



namespace ClassLibrary1
{
    public class Class1
    {
        [TestFixture]
        class CalcTests
        {
            [Test]
            public void GetMultiplication_Input1point2and3point6_Returns31point35()
            {
                //Arrange
                double number1 = 5.7;
                double number2 = 5.5;
                double expectedResult = number1 * number2;
                Calc testCalc = new Calc(number1, number2);
                //Act
                double actualResult = testCalc.GetMultiplication();
                //Assert
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetMultiplication_Input0point9and1point5_Returns1point35()
            {
                //Arrange
                double number1 = 0.9;
                double number2 = 1.5;
                double expectedResult = number1 * number2;
                Calc testCalc = new Calc(number1, number2);
                //Act
                double actualResult = testCalc.GetMultiplication();
                //Assert
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetMultiplication_Input1point7and1point5_Returns2point55()
            {
                //Arrange
                double number1 = 1.7;
                double number2 = 1.5;
                double expectedResult = number1 * number2;
                Calc testCalc = new Calc(number1, number2);
                //Act
                double actualResult = testCalc.GetMultiplication();
                //Assert
                Assert.AreEqual(expectedResult, actualResult);
            }
        }
    }
    
}
